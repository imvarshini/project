export class Employee {
first_name!:string;
middle_name!:string;
last_name!:string;
father_name!:string;
mother_name!:string;
date!:string;

employee_id!:string;
adhar_card!:string;
pan_card!:string;
gender!:string;
language!:string;
mobile_number!:string;
address!:string;
email_id!:string;


}
