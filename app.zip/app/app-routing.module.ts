import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { AddComponent } from './dashboard/add/add.component';
import { ViewComponent } from './dashboard/view/view.component';
import { UpdateComponent } from './dashboard/update/update.component';
import { DeleteComponent } from './dashboard/delete/delete.component';



  const routes: Routes = [
    {path:'',component:WelcomeComponent},



 {path:'welcome',component:WelcomeComponent},



 {path:'login',component:LoginComponent},


 {path:'dashboard',children:[
 {path:'',component:DashboardComponent},
 {path:'view',component:ViewComponent},

 {path:'add',component:AddComponent},

 {path:'update',component:UpdateComponent},

{path:'delete',component:DeleteComponent}]},

 {path:'add',children:[



 {path:'',component:AddComponent},

 {path:'update',component:UpdateComponent},

 {path:'delete',component:DeleteComponent},

 {path:'view',component:ViewComponent},
 {path:'dashboard',component:DashboardComponent},

 {path:'login',component:LoginComponent},



 ]},

 {path:'delete',children:[



 {path:'',component:DeleteComponent},
 {path:'update',component:UpdateComponent},

 {path:'delete',component:DeleteComponent},

 {path:'view',component:ViewComponent},

 {path:'dashboard',component:DashboardComponent},

 {path:'login',component:LoginComponent},

 {path:'add',component:AddComponent}


 ]},

 {path:'update',children:[



 {path:'',component:UpdateComponent},
 {path:'update',component:UpdateComponent},
 {path:'delete',component:DeleteComponent},

 {path:'view',component:ViewComponent},

 {path:'dashboard',component:DashboardComponent},

 {path:'login',component:LoginComponent},

 {path:'add',component:AddComponent}


]},
{path:'view',children:[



{path:'',component:ViewComponent},
 {path:'update',component:UpdateComponent},

{path:'delete',component:DeleteComponent},

{path:'view',component:ViewComponent},

 {path:'dashboard',component:DashboardComponent},

 {path:'login',component:LoginComponent},

 {path:'add',component:AddComponent}


]}



];
    /*
    {path:'',component:WelcomeComponent},
  {path:'welcome',component:WelcomeComponent},
   {path:'login',component:LoginComponent},
 
   {path:'dashboard',children:[
   {path:'',component:DashboardComponent},
   {path:'dashboard',component:DashboardComponent},
   {path:'view',component:ViewComponent},
   {path:'add',component:AddComponent},
   {path:'update',component:UpdateComponent},
   {path:'delete',component:DeleteComponent},
   {path:'login',component:LoginComponent},]},
 
   {path:'add',children:[
     {path:'',component:AddComponent},
     {path:'dashboard',component:DashboardComponent},
     {path:'view',component:ViewComponent},
     {path:'add',component:AddComponent},
     {path:'update',component:UpdateComponent},
     {path:'delete',component:DeleteComponent},
     {path:'login',component:LoginComponent},
   ]},
   {path:'update',children:[
     {path:'',component:UpdateComponent},
     {path:'dashboard',component:DashboardComponent},
     {path:'view',component:ViewComponent},
     {path:'add',component:AddComponent},
     {path:'update',component:UpdateComponent},
     {path:'delete',component:DeleteComponent},
     {path:'login',component:LoginComponent},
   ]},
   {path:'view',children:[
     {path:'',component:ViewComponent},
     {path:'dashboard',component:DashboardComponent},
     {path:'view',component:ViewComponent},
     {path:'add',component:AddComponent},
     {path:'update',component:UpdateComponent},
     {path:'delete',component:DeleteComponent},
     {path:'login',component:LoginComponent},
   ]},
   {path:'delete',children:[
     {path:'',component:DeleteComponent},
     {path:'dashboard',component:DashboardComponent},
     {path:'view',component:ViewComponent},
     {path:'add',component:AddComponent},
     {path:'update',component:UpdateComponent},
     {path:'delete',component:DeleteComponent},
     {path:'login',component:LoginComponent},
 
   ]}
 ];
*/
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
