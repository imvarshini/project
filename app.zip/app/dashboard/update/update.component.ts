import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/employee.service';
import { Employee } from 'src/app/employee';
import { HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import * as alertify from 'alertifyjs';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  employee_id!:string;
  constructor(private employeeService:EmployeeService,private https:HttpClient) { }

  ngOnInit(): void {
    
  }
  onSubmit(data:Employee){
    this.https.post('http://localhost:8089/api/updateemployee/'+`${data.employee_id}`,data).subscribe((result)=>{
    console.log("result",result);
    console.log(data);
    alertify.alert('Success!!','Form is successfully updated');
  })
  
  }}