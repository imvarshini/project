import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/employee.service';
import { Employee } from 'src/app/employee';
import { HttpClient } from '@angular/common/http';
import * as alertify from 'alertifyjs';
@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {
  employeetable!:Employee[];
  constructor(private employeeService:EmployeeService,private https:HttpClient) { }

  ngOnInit(): void {
    
  }
  onSubmit(data:Employee){
    this.https.post('http://localhost:8089/api/deleteemployee/'+`${data.employee_id}`,data).subscribe((result)=>{
    console.log("result",result);
    console.log(data);
  })
  alertify.alert('Success!!','Form is successfully deleted');

}
}
