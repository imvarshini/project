import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  /*add!=Add[];
  constructor(private https:HttpClient){ }
  onsubmit(data:Employee){
  this.https.post('http://localhost:8089/api/employees',data).subscribe((result)=>
  console.warn(data:add))
  }
    constructor() { }
  */
  constructor() { }

  ngOnInit(): void {
  }

}
